
package br.com.aoo.entidade;

import java.util.Date;


public class Animal {
    private Integer id;
    private String nome;
    private Date nascimento ;
    private double peso ;
    private String raca;
    private TipoAnimal TipoAnimal;
    
    
    
    public Animal(){
    }

    public Animal(Integer id, String nome, Date nascimento, double peso, String raca) {
        this.id = id;
        this.nome = nome;
        this.nascimento = nascimento;
        this.peso = peso;
        this.raca = raca;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getNascimento() {
        return nascimento;
    }

    public void setNascimento(Date nascimento) {
        this.nascimento = nascimento;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public TipoAnimal getTipoAnimal() {
        return TipoAnimal;
    }

    public void setTipoAnimal(TipoAnimal TipoAnimal) {
        this.TipoAnimal = TipoAnimal;
    }

    public Object setTipoAnimal() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    

}