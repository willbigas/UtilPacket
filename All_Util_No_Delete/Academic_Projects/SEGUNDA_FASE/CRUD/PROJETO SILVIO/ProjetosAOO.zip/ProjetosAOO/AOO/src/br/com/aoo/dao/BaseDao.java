
package br.com.aoo.dao;

import java.sql.SQLException;
import java.util.List;


public interface BaseDao {
    
    public abstract void salvar(Object object) throws SQLException;
    
    void alterar (Object object) throws  SQLException;
    
    void excluir (Integer id) throws SQLException; 
    
    Object pesquisarPorId(Integer id) throws  SQLException;
    
    List listarTodos() throws  SQLException;

}