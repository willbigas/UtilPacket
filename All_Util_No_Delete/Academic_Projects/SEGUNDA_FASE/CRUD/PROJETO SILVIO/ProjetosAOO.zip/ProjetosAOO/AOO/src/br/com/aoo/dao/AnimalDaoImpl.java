/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.aoo.dao;

import br.com.aoo.entidade.Animal;
import br.com.aoo.entidade.TipoAnimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alunos
 */
public class AnimalDaoImpl implements AnimalDao {

    private Animal animal;
    private Connection conn;
    private PreparedStatement psmt;
    private ResultSet rs;

    @Override
    public void salvar(Object object) throws SQLException {
        animal = (Animal) object;
        try {
            String sql = "INSERT INTO animal(nome, raca, peso, "
                    + "nascimento, idTipoAnimal) Values(?, ?, ?, ?, ?)";
            conn = FabricaConexao.abreConexao();
            psmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            psmt.setString(1, animal.getNome());
            psmt.setString(2, animal.getRaca());
            psmt.setDouble(3, animal.getPeso());
            psmt.setDate(4, new Date(animal.getNascimento().getTime()));
            psmt.setInt(5, animal.getTipoAnimal().getId());
            psmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("Erro ao salvar " + e.getMessage());
        } finally {

        }
    }

    @Override
    public void alterar(Object object) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(Integer id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object pesquisarPorId(Integer id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listarTodos() throws SQLException {
        String sql = "SELECT * FROM animal a join tipoAnimal ta on a.idTipoAnimal = ta.id ;";
        List<Animal> animais = new ArrayList<>();
        TipoAnimal tipoAnimal;
        try {
            conn = FabricaConexao.abreConexao();
            psmt = conn.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
                animal = new Animal();
                animal.setId(rs.getInt("a.id"));
                animal.setNome(rs.getString("a.nome"));
                animal.setRaca(rs.getString("a.raca"));
                animal.setPeso(rs.getDouble("a.peso"));
                animal.setNascimento(rs.getDate("a.nascimento"));
                
                animal.setTipoAnimal(new TipoAnimal());
                animal.getTipoAnimal().setId(rs.getInt("ta.id"));
                animal.getTipoAnimal().setNome(rs.getString("ta.nome"));
                animal.getTipoAnimal().setDescricao(rs.getString("ta.descricao"));
                animais.add(animal);
                
            }

        } catch (Exception e) {
            System.out.println("Erro ao pesquisar todos  " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(conn, psmt, rs);
        }

        return animais;
    }

}
