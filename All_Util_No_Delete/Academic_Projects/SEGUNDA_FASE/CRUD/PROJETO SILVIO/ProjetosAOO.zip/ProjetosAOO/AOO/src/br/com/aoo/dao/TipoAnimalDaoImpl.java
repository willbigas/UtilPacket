package br.com.aoo.dao;

import br.com.aoo.entidade.TipoAnimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoAnimalDaoImpl implements TipoAnimalDao {

    private Connection connection;
    private PreparedStatement ps;
    private ResultSet rs;
    private TipoAnimal tipoAnimal;

    @Override
    public void salvar(Object object) throws SQLException {
        tipoAnimal = (TipoAnimal) object; //casting
        String sql = "INSERT INTO tipoAnimal(nome, descricao) values(?, ?)";
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement(sql);
            ps.setString(1, tipoAnimal.getNome());
            ps.setString(2, tipoAnimal.getDescricao());
            ps.executeUpdate();

        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Erro ao gravar " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
    }

    @Override
    public void alterar(Object object) throws SQLException {
        tipoAnimal = (TipoAnimal) object; //casting
        String sql = "UPDATE tipoanimal SET nome = ?, descricao = ? WHERE id  = ?";
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement(sql);
            ps.setString(1, tipoAnimal.getNome());
            ps.setString(2, tipoAnimal.getDescricao());
            ps.setInt(3, tipoAnimal.getId());
            ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro ao alterar " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
    }

    @Override
    public void excluir(Integer id) throws SQLException {
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement("DELETE FROM tipoanimal where id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Erro ao excluir tipoAnimal " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
    }

    @Override
    public Object pesquisarPorId(Integer id) throws SQLException {
        String consulta = "SELECT * FROM tipoanimal WHERE id = ?";
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement(consulta);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if(rs.next()){
                tipoAnimal = new TipoAnimal();
                tipoAnimal.setId(id);
                tipoAnimal.setNome(rs.getString("nome"));
                tipoAnimal.setDescricao(rs.getString("descricao"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao pesquisar por id " + e.getMessage() );
        }finally{
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
        return tipoAnimal;
    }

    @Override
    public List listarTodos() throws SQLException {
        List<TipoAnimal> tipoAnimals = new ArrayList<>();
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement("SELECT * FROM tipoanimal");
            rs = ps.executeQuery();
            while (rs.next()) {                
                tipoAnimal = new TipoAnimal();
                tipoAnimal.setId(rs.getInt("id"));
                tipoAnimal.setNome(rs.getString("nome"));
                tipoAnimal.setDescricao(rs.getString("descricao"));
                tipoAnimals.add(tipoAnimal);
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar todos " + e.getMessage());
        }finally{
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
        return tipoAnimals;
    }

}
