
package br.com.aoo.dao;


public interface TipoCarroDao extends BaseDao{
    
    
}
