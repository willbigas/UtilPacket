package br.com.aoo.dao;

import br.com.aoo.entidade.TipoCarro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoCarroDaoImpl implements TipoCarroDao {

    private Connection connection;
    private PreparedStatement ps;
    private ResultSet rs;
    private TipoCarro tipoCarro;

    @Override
    public void salvar(Object object) throws SQLException {
        tipoCarro = (TipoCarro) object; //casting
        String sql = "INSERT INTO tipocarro(nome, descricao) values(?, ?)";
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement(sql);
            ps.setString(1, tipoCarro.getNome());
            ps.setString(2, tipoCarro.getDescricao());
            ps.executeUpdate();

        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Erro ao gravar " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
    }

    @Override
    public void alterar(Object object) throws SQLException {
        tipoCarro = (TipoCarro) object; //casting
        String sql = "UPDATE tipocarro SET nome = ?, descricao = ? WHERE id  = ?";
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement(sql);
            ps.setString(1, tipoCarro.getNome());
            ps.setString(2, tipoCarro.getDescricao());
            ps.setInt(3, tipoCarro.getId());
            ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro ao alterar " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
    }

    @Override
    public void excluir(Integer id) throws SQLException {
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement("DELETE FROM tipocarro where id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro ao excluir tipoCarro " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
    }

    @Override
    public Object pesquisarPorId(Integer id) throws SQLException {
        String consulta = "SELECT * FROM tipocarro WHERE id = ?";
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement(consulta);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                tipoCarro = new TipoCarro();
                tipoCarro.setId(id);
                tipoCarro.setNome(rs.getString("nome"));
                tipoCarro.setDescricao(rs.getString("descricao"));
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro ao pesquisar por id " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }

        return tipoCarro;
    }

    @Override
    public List listarTodos() throws SQLException {
        List<TipoCarro> tipoCarros = new ArrayList<>();
        try {
            connection = FabricaConexao.abreConexao();
            ps = connection.prepareStatement("SELECT * FROM tipocarro");
            rs = ps.executeQuery();
            while (rs.next()) {
                tipoCarro = new TipoCarro();
                tipoCarro.setId(rs.getInt("id"));
                tipoCarro.setNome(rs.getString("nome"));
                tipoCarro.setDescricao(rs.getString("descricao"));
                tipoCarros.add(tipoCarro);
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar todos " + e.getMessage());
        } finally {
            FabricaConexao.fecharConexao(connection, ps, rs);
        }
        
        return tipoCarros;
    }

}
