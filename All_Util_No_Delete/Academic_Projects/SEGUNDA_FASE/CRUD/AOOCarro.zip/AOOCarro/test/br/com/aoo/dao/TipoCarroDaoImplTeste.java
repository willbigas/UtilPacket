/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.aoo.dao;

import br.com.aoo.entidade.TipoCarro;
import java.util.List;

/**
 *
 * @author William
 */
public class TipoCarroDaoImplTeste {
    private TipoCarro tipoCarro;
    private TipoCarroDao tipoCarroDao;

    public TipoCarroDaoImplTeste() {
        tipoCarroDao = new TipoCarroDaoImpl();
    }

  //  @Test
    public void testSalvar() throws Exception {
        System.out.println("salvar");
        tipoCarro = new TipoCarro(null, "Fusca", "Tunado , pegador de Calcinha.");
        tipoCarroDao.salvar(tipoCarro);
    }

    
    public void testAlterar() throws Exception {
        System.out.println("alterar");
        tipoCarro = new TipoCarro();
        tipoCarro.setId(1);
        tipoCarro.setNome("Carro alterado");
        tipoCarro.setDescricao("descrição alterada");
        tipoCarroDao.alterar(tipoCarro);

    }

    
    public void testExcluir() throws Exception {
        System.out.println("excluir");
        tipoCarroDao.excluir(1);

    }

   
    public void testPesquisarPorId() throws Exception {
        System.out.println("pesquisarPorId");
        Integer id = 2;
        tipoCarro = (TipoCarro) tipoCarroDao.pesquisarPorId(id);
        System.out.println(tipoCarro);

    }

    
    public void testListarTodos() throws Exception {
        System.out.println("listarTodos");
        List<TipoCarro> tipoCarros = tipoCarroDao.listarTodos();
        for (TipoCarro tCarro : tipoCarros) {
            System.out.println("Id " + tCarro.getId());
            System.out.println("Nome " + tCarro.getNome());
            System.out.println("Descrição " + tCarro.getDescricao());
            System.out.println("");

        }
    }
}
