package br.com.aoo.dao;

import br.com.aoo.entidade.TipoAnimal;
import java.util.List;
import org.junit.Test;

public class TipoAnimalDaoImplTest {

    private TipoAnimal tipoAnimal;
    private TipoAnimalDao tipoAnimalDao;

    public TipoAnimalDaoImplTest() {
        tipoAnimalDao = new TipoAnimalDaoImpl();
    }

//    @Test
    public void testSalvar() throws Exception {
        System.out.println("salvar");
        tipoAnimal = new TipoAnimal(null, "gato", "quadrupede que mia");
        tipoAnimalDao.salvar(tipoAnimal);
    }

    @Test
    public void testAlterar() throws Exception {
        System.out.println("alterar");
        tipoAnimal = new TipoAnimal();
        tipoAnimal.setId(1);
        tipoAnimal.setNome("gato alterado");
        tipoAnimal.setDescricao("descrição alterado");
        tipoAnimalDao.alterar(tipoAnimal);

    }

    @Test
    public void testExcluir() throws Exception {
        System.out.println("excluir");
        tipoAnimalDao.excluir(1);
        
    }

    @Test
    public void testPesquisarPorId() throws Exception {
        System.out.println("pesquisarPorId");
        Integer id = 2;
        tipoAnimal = (TipoAnimal) tipoAnimalDao.pesquisarPorId(id);
        System.out.println(tipoAnimal);
        
        
    }

    @Test
    public void testListarTodos() throws Exception {
        System.out.println("listarTodos");
        List<TipoAnimal> tipoAnimals = tipoAnimalDao.listarTodos();
        for (TipoAnimal tAnimal : tipoAnimals) {
            System.out.println("Id " + tAnimal.getId() );
            System.out.println("Nome " + tAnimal.getNome() );
            System.out.println("Descrição " + tAnimal.getDescricao());
            System.out.println("");
            
            
        }
    }

}
