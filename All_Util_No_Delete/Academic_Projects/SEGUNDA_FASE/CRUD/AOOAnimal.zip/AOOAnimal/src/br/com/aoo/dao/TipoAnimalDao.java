
package br.com.aoo.dao;


public interface TipoAnimalDao extends BaseDao{
    
    
}
