# jsf-objetos
Teste de Objetos em JSF
